# BTCUSDT Dual Spot Grid — DEMO ONLY

Android + GitHub Codespaces starter project. Uses CCXT to connect to:
- Bybit Spot Testnet
- Binance Spot Testnet

## Safety
- Sandbox mode is forced ON in `bot.py` for both exchanges.
- This project does not support live trading.
- Never use live API keys with this project.
- Never commit API keys, `.env` files, or exchange secrets to GitHub.
- Use testnet-only keys with Spot trading permission and withdrawals disabled.

## Project files
- `bot.py` — demo grid engine
- `requirements.txt` — Python dependency
- `.env.example` — names of required environment variables; no real keys
- `.gitignore` — excludes local state and `.env`

## Upload from Android
1. Open https://github.com and sign in.
2. Create a **Private** repository named `btc-dual-spot-grid-demo`.
3. In the repository choose **Add file → Upload files**.
4. Upload `bot.py`, `requirements.txt`, `.env.example`, and `.gitignore`.
5. Tap **Commit changes**.

## Start a Codespace
1. Open the private repository.
2. Tap **Code → Codespaces → Create codespace on main**.
3. Wait for the browser-based VS Code editor to open.
4. Open Terminal → New Terminal.
5. Run:
   ```bash
   pip install -r requirements.txt
   ```

## Add testnet API credentials securely
In the repository go to **Settings → Secrets and variables → Codespaces → New repository secret**.
Create these four secrets, using TESTNET keys only:
- `BYBIT_API_KEY`
- `BYBIT_API_SECRET`
- `BINANCE_API_KEY`
- `BINANCE_API_SECRET`

Codespaces makes repository Codespaces secrets available as environment variables after the Codespace is restarted/rebuilt. Do not paste keys into the terminal, code, chat, or repository files.

## Demo procedure
1. Create Bybit Testnet API credentials at https://testnet.bybit.com/ .
2. Create Binance Spot Test Network credentials at https://testnet.binance.vision/ .
3. Make sure both testnet wallets have test USDT. The bot's planned budget is 50 USDT per exchange.
4. In the Codespaces terminal, first run:
   ```bash
   export DRY_RUN=true
   python bot.py
   ```
   This checks connectivity and logs simulated grid orders; it does not place orders.
5. Stop the bot with Ctrl+C.
6. If you want to place actual **testnet** orders, confirm both keys are testnet-only, set:
   ```bash
   export DRY_RUN=false
   ```
   If you previously ran dry-run, remove the simulated state file before starting:
   ```bash
   rm -f grid_state.json
   ```
7. Run:
   ```bash
   python bot.py
   ```

## Bot behavior and limitations
- Calculates an automatic range from recent 1-hour candle ranges, bounded to +/-0.75% to +/-3%.
- Places up to five initial limit BUY orders, sharing the configured 50 USDT budget on each exchange.
- After a BUY fills, places a SELL one grid step above; after a SELL fills, places a new BUY one grid step below.
- Set `QUOTE_BUDGET` to change the per-exchange testnet budget; default is 50.
- Exchange minimum order values, available testnet balances, fees, and API behavior can prevent orders from being accepted.
- `grid_state.json` tracks order IDs and is stored in the Codespace workspace. Do not publish it.
- Codespaces is not an always-on server. If it stops, the bot stops; existing exchange testnet orders may remain active.
- This is educational starter code, not audited or production-ready trading software. Test order behavior and recovery thoroughly before considering any real-money system.
