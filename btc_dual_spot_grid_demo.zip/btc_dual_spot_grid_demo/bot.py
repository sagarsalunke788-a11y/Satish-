"""
BTCUSDT Dual-Exchange Spot Grid Bot — DEMO ONLY
Runs on Bybit Spot Testnet and Binance Spot Testnet using CCXT.

Safety:
- Sandbox mode is forced on for both exchanges.
- No live-trading switch is provided.
- API keys must be stored as Codespaces Secrets / environment variables.
- This is starter software: test carefully with tiny testnet orders first.
"""
import os
import json
import time
import logging
from pathlib import Path
from datetime import datetime, timezone

import ccxt

SYMBOL = "BTC/USDT"
QUOTE_BUDGET = float(os.getenv("QUOTE_BUDGET", "50"))  # per exchange, testnet only
GRID_LEVELS = int(os.getenv("GRID_LEVELS", "5"))
POLL_SECONDS = int(os.getenv("POLL_SECONDS", "20"))
STATE_FILE = Path(os.getenv("STATE_FILE", "grid_state.json"))
DRY_RUN = os.getenv("DRY_RUN", "true").lower() == "true"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s"
)
log = logging.getLogger("demo-grid")


def make_exchange(exchange_id):
    key = os.getenv(f"{exchange_id.upper()}_API_KEY")
    secret = os.getenv(f"{exchange_id.upper()}_API_SECRET")
    if not key or not secret:
        raise RuntimeError(f"Missing {exchange_id} API key/secret environment variables")

    klass = getattr(ccxt, exchange_id)
    ex = klass({
        "apiKey": key,
        "secret": secret,
        "enableRateLimit": True,
        "options": {"defaultType": "spot"},
    })
    # Force test environment. Never remove these lines for this demo project.
    ex.set_sandbox_mode(True)
    ex.load_markets()
    if SYMBOL not in ex.markets:
        raise RuntimeError(f"{SYMBOL} is not available in {exchange_id} sandbox")
    return ex


def load_state():
    if STATE_FILE.exists():
        return json.loads(STATE_FILE.read_text())
    return {}


def save_state(state):
    tmp = STATE_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(state, indent=2))
    tmp.replace(STATE_FILE)


def auto_grid(ex):
    """Use recent 1h candles to estimate a volatility-based range."""
    candles = ex.fetch_ohlcv(SYMBOL, timeframe="1h", limit=30)
    if len(candles) < 15:
        raise RuntimeError("Not enough candle data to calculate automatic range")
    ranges = []
    for c in candles[-14:]:
        high, low, close = float(c[2]), float(c[3]), float(c[4])
        ranges.append((high - low) / close if close else 0)
    avg_range = sum(ranges) / len(ranges)
    ticker = ex.fetch_ticker(SYMBOL)
    price = float(ticker["last"])
    # Range is bounded to avoid an excessively wide/narrow grid.
    half_width = max(0.0075, min(0.03, avg_range * 2.0))
    lower = price * (1 - half_width)
    upper = price * (1 + half_width)
    step = (upper - lower) / (GRID_LEVELS + 1)
    return price, lower, upper, step


def free_balance(ex, currency):
    bal = ex.fetch_balance()
    item = bal.get(currency, {})
    return float(item.get("free") or 0)


def amount_for_cost(ex, price, cost):
    raw = cost / price
    return float(ex.amount_to_precision(SYMBOL, raw))


def place_limit(ex, side, price, amount):
    price = float(ex.price_to_precision(SYMBOL, price))
    amount = float(ex.amount_to_precision(SYMBOL, amount))
    if amount <= 0:
        raise RuntimeError("Order amount rounded to zero")
    market = ex.market(SYMBOL)
    limits = market.get("limits", {})
    min_amount = (limits.get("amount") or {}).get("min")
    min_cost = (limits.get("cost") or {}).get("min")
    if min_amount and amount < float(min_amount):
        raise RuntimeError(f"Order amount {amount} is below exchange minimum {min_amount}")
    if min_cost and amount * price < float(min_cost):
        raise RuntimeError(
            f"Order value {amount * price:.4f} USDT is below exchange minimum {min_cost}"
        )
    if DRY_RUN:
        log.info("[DRY_RUN] Would place %s %.8f %s at %.2f", side, amount, SYMBOL, price)
        return {"id": f"dry-{int(time.time()*1000)}", "status": "open",
                "side": side, "price": price, "amount": amount}
    return ex.create_limit_order(SYMBOL, side, amount, price)


def start_grid(ex, exchange_id, state):
    price, lower, upper, step = auto_grid(ex)
    log.info("%s auto range: price=%.2f lower=%.2f upper=%.2f step=%.2f",
             exchange_id, price, lower, upper, step)

    # Keep only five initial BUY levels below the current market.
    # SELL orders are created only after a BUY order fills.
    per_order_quote = QUOTE_BUDGET / GRID_LEVELS
    quote_free = free_balance(ex, "USDT")
    if not DRY_RUN and quote_free < QUOTE_BUDGET:
        raise RuntimeError(
            f"{exchange_id}: testnet free USDT {quote_free:.4f} is less than "
            f"the configured {QUOTE_BUDGET:.2f}. Fund the testnet wallet first."
        )

    state[exchange_id] = {"orders": {}, "started_at": datetime.now(timezone.utc).isoformat()}
    for level in range(1, GRID_LEVELS + 1):
        buy_price = price - step * level
        amount = amount_for_cost(ex, buy_price, per_order_quote)
        order = place_limit(ex, "buy", buy_price, amount)
        state[exchange_id]["orders"][str(order["id"])] = {
            "role": "buy", "price": buy_price, "amount": amount, "level": level
        }
        save_state(state)
    log.info("%s initial grid placed. Testnet only.", exchange_id)


def process_orders(ex, exchange_id, state):
    bucket = state.setdefault(exchange_id, {"orders": {}})
    tracked = bucket.setdefault("orders", {})
    for order_id, meta in list(tracked.items()):
        if str(order_id).startswith("dry-"):
            continue
        try:
            order = ex.fetch_order(order_id, SYMBOL)
        except Exception as err:
            log.warning("%s cannot fetch order %s: %s", exchange_id, order_id, err)
            continue

        if order.get("status") != "closed":
            continue

        role = meta["role"]
        old_price = float(meta["price"])
        amount = float(meta["amount"])
        del tracked[order_id]
        save_state(state)

        if role == "buy":
            # Sell one grid step above the filled buy.
            _, _, _, step = auto_grid(ex)
            sell_price = old_price + step
            # Small haircut for possible base-asset fees.
            sell_amount = amount * 0.998
            new_order = place_limit(ex, "sell", sell_price, sell_amount)
            tracked[str(new_order["id"])] = {
                "role": "sell", "price": sell_price,
                "amount": sell_amount, "level": meta.get("level", 0)
            }
            log.info("%s BUY filled; SELL placed above at %.2f", exchange_id, sell_price)
        else:
            # Re-enter one grid step below the filled sell.
            _, _, _, step = auto_grid(ex)
            buy_price = max(0.01, old_price - step)
            buy_amount = amount_for_cost(ex, buy_price, amount * old_price * 0.998)
            new_order = place_limit(ex, "buy", buy_price, buy_amount)
            tracked[str(new_order["id"])] = {
                "role": "buy", "price": buy_price,
                "amount": buy_amount, "level": meta.get("level", 0)
            }
            log.info("%s SELL filled; BUY re-entry placed at %.2f", exchange_id, buy_price)

        save_state(state)


def run_exchange(ex, exchange_id, state):
    if exchange_id not in state or not state[exchange_id].get("orders"):
        start_grid(ex, exchange_id, state)
    else:
        log.info("%s resuming saved order tracking", exchange_id)


def main():
    if GRID_LEVELS < 2 or GRID_LEVELS > 10:
        raise RuntimeError("GRID_LEVELS must be between 2 and 10")
    log.info("Starting DEMO-ONLY BTC/USDT Spot Grid. DRY_RUN=%s", DRY_RUN)
    log.info("Sandbox mode is forced ON in code.")
    exchanges = {}
    for exchange_id in ("bybit", "binance"):
        exchanges[exchange_id] = make_exchange(exchange_id)

    state = load_state()
    for exchange_id, ex in exchanges.items():
        run_exchange(ex, exchange_id, state)
    save_state(state)

    while True:
        for exchange_id, ex in exchanges.items():
            try:
                process_orders(ex, exchange_id, state)
            except Exception:
                log.exception("%s loop error; will retry", exchange_id)
        save_state(state)
        time.sleep(POLL_SECONDS)


if __name__ == "__main__":
    main()
